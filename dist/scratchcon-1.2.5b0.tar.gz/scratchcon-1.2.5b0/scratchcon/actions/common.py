class Public:
    project_id = None
    studio_id = None
    login = None


public = Public()
