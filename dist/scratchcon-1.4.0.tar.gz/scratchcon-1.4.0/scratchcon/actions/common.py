class Public:
    project_id = None
    studio_id = None
    login = None
    username = None


public = Public()
