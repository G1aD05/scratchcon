class Public:
    user_link = None
    project_link = None
    studio_link = None
    login = None
    project_id = None


public = Public()
